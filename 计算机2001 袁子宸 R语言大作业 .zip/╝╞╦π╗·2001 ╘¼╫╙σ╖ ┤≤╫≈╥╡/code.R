##  读入数据，并根据说明文档对income数据集添加列名


income=read.table("D:\\income\\Income.data",sep = ',')
colnames(income)=c('age','workclass','fnlwgt', 'education','education-num',
                   'marital-status','occupation', 'relationship', 'race',
                   'sex','capital-gain','capital-loss',
                   'hours-per-week','native-country','salary')



##  数据处理------缺失值检查

#在查看数据时，发现有些变量取值为'?'，使用缺失值查看检测不出来此异常值，因此需要先将'?'设为NA，再进行缺失值处理


income[income==' ?']=NA


#再利用VIM包中的aggr函数进行缺失值的可视化


library(VIM)
aggr(income,col=c("blue","red"),prop=TRUE,numbers=TRUE)


#图中红色为缺失值，蓝色为完好数据。左边的直方图与右边的分布图显示，变量age、occupation、native-country中存在缺失值。通过左边直方图显示，这三个变量下缺失值占比都非常小，因此采用直接将缺失值所在的行删除的处理方法。


income=na.omit(income)
sum(is.na(income))


#此时，数据中已不含缺失值。

##  查看数据

#——查看样本salary的分布情况

table(income$salary)
barplot(table(income$salary),xlab = 'class',ylab = 'Freq')

#从上述图表中可以直观看到，在数据集中年薪超过5万的样本数远小于年薪小于5万的样本数。

#——查看并设置变量属性

str(income)

#从变量类型中看到，原始的分类变量的数据类型为字符型，需要将其转换为因子型变量；其他指标在解释文档中标注了为连续型，需要将其转换为数值型变量。


income$age=as.numeric(income$age)
income$fnlwgt=as.numeric(income$fnlwgt)
income$`education-num`=as.numeric(income$`education-num`)
income$`capital-gain`=as.numeric(income$`capital-gain`)
income$`capital-loss`=as.numeric(income$`capital-loss`)
income$`hours-per-week`=as.numeric(income$`hours-per-week`)

income$workclass=as.factor(income$workclass)
income$education=as.factor(income$education)
income$`marital-status`=as.factor(income$`marital-status`)
income$occupation=as.factor(income$occupation)
income$relationship=as.factor(income$relationship)
income$race=as.factor(income$race)
income$sex=as.factor(income$sex)
income$`native-country`=as.factor(income$`native-country`)





##  Logistic


income[income$salary==" <=50K",]$salary=0
income[income$salary==" >50K",]$salary=1
income$salary=as.numeric(income$salary)


#交叉验证

library(caret)#做交叉验证用
set.seed(1)
income=income[,-14]
folds=createFolds(y=income$salary,k=10)
ACC=c()
for (i in 1:10) {
  fold_test=income[folds[[i]],] #从income中选取1折作为测试样本
  fold_train=income[-folds[[i]],] #其余数据作为训练样本
  
  fold_model= glm(salary~.,data = fold_train,family = 'binomial')
  fold_pred = predict(fold_model,newdata=fold_test)
  
  #上面fold_pred得到的是概率，要将大于0.5的记为1类
  fold_pred[fold_pred>=0.5]=1
  fold_pred[fold_pred<0.5]=0
  
  #准确率
  fold_true_pred = data.frame(prediction=fold_pred,true=fold_test$salary)
  tab=table(fold_true_pred)
  fold_acc=sum(diag(tab))/sum(tab)
  ACC[i]=fold_acc
}

which(ACC==max(ACC))

#将第7份作为测试样本时，其他作为训练样本时，准确率最高

#下面将income分为训练样本和测试样本，测试样本的行号为第7折

train=income[-folds[[7]],]
test=income[folds[[7]],]
set.seed(1)
model=glm(salary~.,data = train)



summary(model)
coefficients(model)


#对测试集test进行预测

pred = predict(model,newdata=test) 


#绘制ROC曲线

library(pROC)
ROC=roc(test$salary,pred)
plot(ROC, print.auc=TRUE, auc.polygon=TRUE, grid=c(0.1, 0.2),grid.col=c("green", "red"),
     max.auc.polygon=TRUE,auc.polygon.col="lightsteelblue1",
     print.thres=TRUE,main='ROC of RF(CV)')


#上面pred得到的是概率，要将大于0.5的记为1类，计算准确率

pred[pred>=0.5]=1
pred[pred<0.5]=0
#将真实值和预测值整合到一起
true_pred = data.frame(prediction=pred,true=test$salary)
#输出混淆矩阵
tab=table(test$salary,pred,dnn=c("真实值","预测值"))
acc=sum(diag(tab))/sum(tab)
acc


#精确率

P=tab[1]/sum(tab[1,])
P

#召回率

R=tab[1]/sum(tab[,1])
R


#F-score

F_score=2*P*R/(P+R)
F_score

#模型的分类准确率为83.1%，精确率为93.7%，说明模型对收入>=50k的识别有较高精度；召回率为85.2%，F-score为0.89，较高，说明模型的分类效果较为有效。

##  模型改进

#在上部分建模中，删去了分类变量native-country，这是因为该变量取值为'Holand-Netherlands'的仅有一条记录，因此在进行交叉验证时，会导致有一个测试集中包含这条记录，但是在测试集中没有训练到，模型会报错。
#由于income数据的分类变量过多，通过图形查看分布特征。

#因子型变量的图形探究

par(mfrow=c(2,4))
barplot(sort(table(income$workclass),decreasing = T))
barplot(sort(table(income$education),decreasing = T))
barplot(sort(table(income$`marital-status`),decreasing = T))
barplot(sort(table(income$occupation),decreasing = T))
barplot(sort(table(income$relationship),decreasing = T))
barplot(sort(table(income$race),decreasing = T))
barplot(sort(table(income$sex),decreasing = T))


#从图形中看到，education和occupation的取值类型过多，考虑将这两个变量剔除，在进行glm


income=income[,-c(4,7)]
set.seed(2)
folds=createFolds(y=income$salary,k=10)
ACC=c()
for (i in 1:10) {
  fold_test=income[folds[[i]],] #从income中选取1折作为测试样本
  fold_train=income[-folds[[i]],] #其余数据作为训练样本
  
  fold_model= glm(salary~.,data = fold_train,family = 'binomial')
  fold_pred = predict(fold_model,newdata=fold_test)
  
  #上面fold_pred得到的是概率，要将大于0.5的记为1类
  fold_pred[fold_pred>=0.5]=1
  fold_pred[fold_pred<0.5]=0
  
  #准确率
  fold_true_pred = data.frame(prediction=fold_pred,true=fold_test$salary)
  tab=table(fold_true_pred)
  fold_acc=sum(diag(tab))/sum(tab)
  ACC[i]=fold_acc
}

which(ACC==max(ACC))


train=income[-folds[[5]],]
test=income[folds[[5]],]
set.seed(2)
model=glm(salary~.,data = train)



pred = predict(model,newdata=test) 
pred[pred>=0.5]=1
pred[pred<0.5]=0
#将真实值和预测值整合到一起
true_pred = data.frame(prediction=pred,true=test$salary)
#输出混淆矩阵
tab=table(test$salary,pred,dnn=c("真实值","预测值"))
acc=sum(diag(tab))/sum(tab)
acc


#精确率

P=tab[1]/sum(tab[1,])
P

#召回率

R=tab[1]/sum(tab[,1])
R


#F-score

F_score=2*P*R/(P+R)
F_score


#进行模型改进后，模型的分类准确率和精确率都有了提升。